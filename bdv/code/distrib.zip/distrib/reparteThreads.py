# -*- coding: UTF-8 -*-

import threading, time, Queue

class MiHilo(threading.Thread):
    def __init__(self, nroHilo, funcion, colaIn, colaOut):
        self.yo = nroHilo
        self.funcion = funcion
        self.colaIn = colaIn
        self.colaOut = colaOut
        threading.Thread.__init__(self)
        
    def run(self):
#        print "      Thread %d: Arrancando" % self.yo
        while True:
            payload = self.colaIn.get()
            if payload is "quit":
#                print "      Thread %d: Saliendo" % self.yo
                return
#            print "      Thread %d: Ejecutando la funcion %r con args %r" % (self.yo, id(self.funcion), payload)
            result = self.funcion(*payload)
#            print "      Thread %d: Fin funcion %r, result: %r" % (self.yo, id(self.funcion), result)
            self.colaOut.put(result)
        return



class Repartidor:
    """Clase que recibe varios destinos y una función. """

    def __init__(self, destinos, nombreFunc):
        self._cantdest = len(destinos)
        self._disponibles = [True] * self._cantdest
        self._resultados = []
        self._encolados = []

        # lanzamos los n hilos para cada destino
        self.qEnviar = [Queue.Queue() for x in range(self._cantdest)]
        self.qRecbir = [Queue.Queue() for x in range(self._cantdest)]
        for i in range(self._cantdest):
            funcion = getattr(destinos[i], nombreFunc)
            h = MiHilo(i, funcion, self.qEnviar[i], self.qRecbir[i])
            h.start()

    def encolar(self, *payload):
        """ Encola un payload para luego entregarlo en algún momento a algún destino. """
        self._encolados.append(payload)

    def procesar(self, *args):
        """ Procesa los encolados.

        Los desparrama entre los destinos, en paralelo, mientras estén libres. Va
        juntando los resultados y sale cuando ya esté todo procesado, devolviendo
        la lista de resultados.
        """

        # ejecutamos mientras tengamos encolados pendientes o haya un destino sin terminar
        while self._encolados or sum(self._disponibles) < self._cantdest:
            print "\nHay encolados (%d) o estamos esperando algun trabajo (%r)" % (len(self._encolados), self._disponibles)

            # si hay algún hilo libre le damos trabajo (si hay)
            if self._encolados and True in self._disponibles:
                payload = self._encolados.pop()
                libre = self._disponibles.index(True)
                q = self.qEnviar[libre]
                q.put(payload)
                self._disponibles[libre] = False
                print "  Enviamos %r al hilo %d" % (payload, libre)

            # revisamos los pendientes, para ver si terminó alguno
            for i in range(self._cantdest):
                if self._disponibles[i]:
                    continue
                try:
                    result = self.qRecbir[i].get(timeout=.5)
                except Queue.Empty:
                    continue

                # tenemos un dato de alguno
                print "  Recibimos %r del hilo %d" % (result, i)
                self._resultados.append(result)
                self._disponibles[i] = True

            # dormimos para que el while no me ocupe todo el procesador
            time.sleep(.5)

        # terminamos todo, limpiamos y nos vamos
        print "Terminamos todo, nos vamos!"
        for q in self.qEnviar:
            q.put("quit")

        return self._resultados
