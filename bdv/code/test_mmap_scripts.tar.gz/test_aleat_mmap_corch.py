import time, random, mmap

f = open("bigfile")
m = mmap.mmap(f.fileno(), 100000000, access=mmap.ACCESS_READ)

posics = [random.randint(0,99999999) for x in xrange(200000)]
tini = time.time()
for pos in posics:
    b = m[pos:pos+450]
print "Lectura aleatoria con mmap/read:", time.time() - tini
