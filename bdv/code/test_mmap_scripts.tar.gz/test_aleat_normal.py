import time, random

f = open("bigfile")
posics = [random.randint(0,99999999) for x in xrange(200000)]
tini = time.time()
for pos in posics:
    f.seek(pos)
    b = f.read(450)
print "Lectura aleatoria con read:", time.time() - tini
