import time

f = open("bigfile")
tini = time.time()
for i in xrange(200000):
    a = f.read(50)
    b = f.read(450)
print "Lectura secuencial con read:", time.time() - tini
