import time, mmap

f = open("bigfile")
m = mmap.mmap(f.fileno(), 100000000, access=mmap.ACCESS_READ)

tini = time.time()
for i in xrange(200000):
    a = m[i:i+50]
    b = m[i+50:i+500]
print "Lectura secuencial con mmap/corchete:", time.time() - tini
