import time, mmap

f = open("bigfile")
m = mmap.mmap(f.fileno(), 100000000, access=mmap.ACCESS_READ)

tini = time.time()
for i in xrange(200000):
    a = m.read(50)
    b = m.read(450)
print "Lectura secuencial con mmap/read:", time.time() - tini
