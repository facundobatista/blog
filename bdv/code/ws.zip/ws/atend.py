import time

nop = None

class Atendedores(object):

    def duerme(self, parametros):
        t = parametros["tiempo"][0]
        time.sleep(int(t))
        return ("", "text/html")

    def buscar(self, parametros):
        request = repr(parametros)
        time.sleep(10)
        return (request, "text/html")

    def suma(self, parametros):
        tot = sum([int(x[0]) for x in parametros.values()])
        return (str(tot), "text/html")

    def resta(self, parametros):
        (x, y) = parametros.values()
        print x, y
        a = int(x[0])
        b = int(y[0])
        print a, b
        return (str(a-b), "text/html")

    def mult(self, parametros):
        tot = 1
        for x in parametros.values():
            tot *= int(x[0])
        return (str(tot), "text/html")

    def vacio(self, parametros):
        return ("", "text/html")
