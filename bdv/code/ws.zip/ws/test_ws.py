import urllib2

# accedemos una URL y traemos el resultado
u = urllib2.urlopen("http://localhost:9876/index.html")
print u.headers.keys() 
print u.headers["content-length"]
print u.headers["content-type"]
print u.read()

# impactamos en una URL, pasando info por GET
u = urllib2.urlopen("http://localhost:9876/atend/Atendedores/mult?a=5&b=12")
print u.read()

# impactamos en una URL, pasando el pedido por POST (post-form)
u = urllib2.urlopen("http://localhost:9876/buscar", data="textentry=as&booscar=Booscar")
print u.read()

# impactamos en una URL, pasando cualquier info por POST (post-http)
u = urllib2.urlopen("http://localhost:9876/buscar", data="Esto es lo que se me canta enviar al server")

# impactamos en una URL, pasando info en el header
r = urllib2.Request("http://localhost:9876/buscar", headers={"X-CualquierCosa":"Info extra", "OtroHeader":"M�s info"})
u = urllib2.urlopen(r)
u.read()
