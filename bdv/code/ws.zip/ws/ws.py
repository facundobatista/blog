# -*- coding: UTF-8 -*-

import sys, os, cgi, time, urllib2
import SimpleHTTPServer, SocketServer

debugmode = False
cacheMetodos = {}
cacheClases = {}
impModulos = set()

class ManejaPedidos(SimpleHTTPServer.SimpleHTTPRequestHandler):
    '''Clase que se instancia para cada pedido HTTP.'''

    def do_POST(self):
        '''Sirve un pedido POST.'''
        largoData = int(self.headers["content-length"])
        data = self.rfile.read(largoData)
        print repr(data)
        if data == "flush caches":
            self.flush_all()
            self.send_error(205)
            return
        self.send_error(404)
        return

    def do_GET(self):
        '''Sirve un pedido GET.'''

        # separamos los elementos
        (scheme, netloc, path, query, fragment) = urllib2.urlparse.urlsplit(self.path)

        # procesamos la URL y ejecutamos
        # ante cualquier problema, "not found"
        try:
            (root, modulo, clase, metodo) = path.split("/")
            params = cgi.parse_qs(query, keep_blank_values=1)
            result = self.servir(modulo, clase, metodo, params)
        except:
            self.send_error(404)
            return

        # contestamos al browser
        (contenido, tipo) = result
        self.send_response(200)
        self.send_header("content-type", tipo)
        self.send_header("content-length", len(contenido))
        self.end_headers()
        self.wfile.write(contenido)
        return

    def servir(self, modulo, clase, metodo, params):
        '''Ejecutamos el m�todo correspondiente.'''
        if debugmode:
            realmod = __import__(modulo)
            reload(realmod)
            realclase = getattr(realmod, clase)
            obj = realclase()
            realmet = getattr(obj, metodo)
            return realmet(params)

        if metodo in cacheMetodos:           # si ya ten�amos m�todo, lo tomamos
            realmet = cacheMetodos[(modulo, clase, metodo)]
        elif clase in cacheClases:           # nos fijamos si tenemos la clase, al menos
            obj = cacheClases[(modulo, clase)]
            realmet = getattr(obj, metodo)
            cacheMetodos[metodo] = realmet
        else:                                # hacemos todo el trabajo...
            realmod = __import__(modulo)
            realclase = getattr(realmod, clase)
            obj = realclase()
            realmet = getattr(obj, metodo)
            impModulos.add(modulo)
            cacheClases[(modulo, clase)] = obj
            cacheMetodos[(modulo, clase, metodo)] = realmet
        return realmet(params)

    def flush_all(self):
        cacheMetodos.clear()
        cacheClases.clear()
        for m in impModulos:
            del sys.modules[m]
        impModulos.clear()
        return


class MyServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    pass
        
if __name__=="__main__":
    if len(sys.argv) != 2 or not sys.argv[1].isdigit():
        print "Usar: ws.py <puerto>"
        sys.exit()
    port = int(sys.argv[1])
    s = MyServer(('',port),ManejaPedidos)
    s.serve_forever()
