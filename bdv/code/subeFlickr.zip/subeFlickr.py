#!/usr/bin/env python
# -*- coding: utf8 -*- 

import sys, time, os
from flickrapi import FlickrAPI

# En XXX reemplacen con el lugar donde tienen esa info
APIKEY = open("/XXX/.flickr/api_key.txt").read().strip()
SECRET = open("/XXX/.flickr/sharedsecret.txt").read().strip()

# Pongan aquí el NSID vuestro (algo como 39823739@M00, se los da Flickr)
NSID = "XXX"

class Tiempo(object):
    def __init__(self, verbose):
        self.verbose = verbose
    def ini(self, msg):
        self.tini = time.time()
        if self.verbose:
            print "%s..." % msg,
            sys.stdout.flush()
    def fin(self, msg="Ok"):
        if self.verbose:
            print " %s  (%.1f)" % (msg, time.time()-self.tini)
        

def lleva(imgs, setname, descrip, tags, isfriend, ispublic, isfamily, inicial, verbose=False):
    # convertimos params
    isfriend = str(int(isfriend))
    ispublic = str(int(ispublic))
    isfamily = str(int(isfamily))
    tiempo = Tiempo(verbose)

    # levantamos toda la info de auth
    tiempo.ini("Autenticando")
    fapi = FlickrAPI(APIKEY, SECRET)

#   XXX: Aqui hay dos lineas casi iguales, la que tiene lo del browser
#   les va a abrir el navegador la primera vez para que Flickr autentique,
#   y luego de eso no hace más falta, pueden comentar la primer linea y 
#   descomentar la segunda
    token = fapi.getToken(perms="write", browser="firefox")
#    token = fapi.getToken(perms="write")

    tiempo.fin()

    # averiguamos la info del set
    tiempo.ini("Controlando el set")
    rsp = fapi.photosets_getList(api_key=APIKEY, user_id=NSID, auth_token=token)
    fapi.testFailure(rsp)
    try:
        photosets = getattr(rsp.photosets[0], "photoset")
    except AttributeError:
        mustCreate = True
    else:
        for photoset in rsp.photosets[0].photoset:
            tit = photoset.title[0].elementText
            if setname == tit:
                photosetid = photoset.attrib["id"]
                mustCreate = False
                
                # averiguamos que fotos ya tiene el set
                rsp = fapi.photosets_getPhotos(api_key=APIKEY, photoset_id=photosetid, auth_token=token)
                fapi.testFailure(rsp)
                yasubidas = set(photo.attrib["title"] for photo in rsp.photoset[0].photo)
                break
        else:
            mustCreate = True
            yasubidas = set()

            # acomodamos para que arranque con la inicial, si hay una
            if inicial:
                inibase = os.path.basename(inicial)
                for img in imgs:
                    imgbase = os.path.basename(img)
                    if imgbase == inibase:
                        imgs.remove(img)
                        imgs.insert(0, img)
                        break
                
    if mustCreate:
        tiempo.fin("Lo tenemos que crear!")
    else:
        tiempo.fin(u"Ya lo teníamos: id=%s" % photosetid)
    
    # leemos la imagen y la subimos
    totalimgs = len(imgs)
    for num,nomimg in enumerate(imgs):
        img = open(nomimg).read()

        # control para no repetir
        tiempo.ini("Subiendo %s (%d/%d)" % (nomimg, num+1, totalimgs))
        title = os.path.basename(nomimg)
        if title in yasubidas:
            tiempo.fin("ya estaba subida!")
            continue

        # subimos la foto
        rsp = fapi.upload(jpegData=img, api_key=APIKEY, auth_token=token,
                title=title, description=descrip, tags=tags,
                is_friend=isfriend, is_public=ispublic, is_family=isfamily)
        fapi.testFailure(rsp)
        pid = rsp.photoid[0].elementText
        tiempo.fin()

        # creamos el set si correspondía, con la foto directamente
        if mustCreate:
            tiempo.ini("Creando el set con la img recién subida")
            rsp = fapi.photosets_create(api_key=APIKEY, title=setname, description=descrip, primary_photo_id=pid, auth_token=token)
            fapi.testFailure(rsp)
            mustCreate = False
            photosetid = rsp.photoset[0].attrib["id"]
            tiempo.fin()
        else:
            tiempo.ini("Agregando img al set")
            rsp = fapi.photosets_addPhoto(api_key=APIKEY, photoset_id=photosetid, photo_id=pid, auth_token=token)
            fapi.testFailure(rsp)
            tiempo.fin()
    return


if __name__ == "__main__":
    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("-t", "--tags", dest="tags", default="", help="lista de palabras para el comentario ([''])")
    parser.add_option("-y", "--family", action="store_true", dest="isfamily", default=False, help="marca a las fotos como de 'familia'")
    parser.add_option("-f", "--friend", action="store_true", dest="isfriend", default=False, help="marca a las fotos como de 'familia' y 'amigos'")
    parser.add_option("-p", "--public", action="store_true", dest="ispublic", default=False, help="marca a las fotos como 'pública'")
    parser.add_option("-q", "--quiet", action="store_false", dest="verbose", default=True, help="no tira mensajes de lo que va pasando ([False])")
    parser.add_option("-d", "--descrip", dest="descrip", help="descripcion de la foto")
    parser.add_option("-i", "--inicial", dest="inicial", help="foto inicial, sólo usada si se crea un set")
    parser.add_option("-s", "--set", dest="setname", help="nombre del set")
    (opts, args) = parser.parse_args()
    if opts.descrip is None or opts.setname is None:
        print parser.format_help()
        sys.exit()

    # Solo puede indicarse uno de [yfp], y necesariamente uno.
    if sum((opts.ispublic, opts.isfriend, opts.isfamily)) != 1:
        print "Error: Puede ser Pública, o Amigos, o Familia; uno de ellos, ni más ni menos"
        sys.exit()
        
    if opts.ispublic:
        ispublic = True
        isfriend = False
        isfamily = False
    elif opts.isfriend:
        ispublic = False
        isfriend = True
        isfamily = True
    elif opts.isfamily:
        ispublic = False
        isfriend = False
        isfamily = True

    descrip = opts.descrip.decode("utf8")
    tags = opts.tags.decode("utf8")
    setname = opts.setname.decode("utf8")

    lleva(args, setname, descrip, tags, isfriend, ispublic, isfamily, opts.inicial, opts.verbose)
