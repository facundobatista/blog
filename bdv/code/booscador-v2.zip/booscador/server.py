# -*- coding: UTF-8 -*-
import sys, os, cgi
import cStringIO, cPickle
import SimpleHTTPServer, SocketServer

class BuscarIndice(object):
    def __init__(self, archivo):
        self.indice = cPickle.load(open(archivo))

    def __call__(self, busq):
        pag = ["Coincidencias exactas:<br /><br />"]
        pag.extend(self.busq_exacta(busq))
        pag.append("<br /><br /><br />Coincidencias parciales:<br /><br />")
        pag.extend(self.busq_parcial(busq))
        return '\n'.join(pag)

    def busq_exacta(self, busq):
        info = self.indice.get(busq, [])
        return self.arma_tabla(info)

    def busq_parcial(self, busq):
        dic = {}
        allcoinc = [v for (k,v) in self.indice.items() if busq in k]
        for urlcoinc in allcoinc:
            for (cant, tit, url) in urlcoinc:
                clave = (tit, url)
                dic[clave] = dic.get(clave, 0) + cant
        info = [(cant, tit, url)  for ((tit, url), cant) in dic.items()]
        info.sort(reverse=True)
        return self.arma_tabla(info)

    def arma_tabla(self, info):
        if not len(info):
            return "Ninguna"
        pag = ["<table cellspacing=5 cellpadding=5>"]
        for (cant, tit, url) in info:
            pag.append('<tr><td><a href="%s">%s</a></td>' % (url, tit))
            pag.append("<td>%s</td></tr>" % cant)
        pag.append("</table>")
        return pag

buscarIndice = BuscarIndice("indice.dat")

class ManejaPedidos(SimpleHTTPServer.SimpleHTTPRequestHandler):
    """Clase que se instancia para cada pedido HTTP."""

    def do_GET(self):
        """Sirve un pedido GET."""
        # analiza el string del pedido
        if self.path.find('?') > -1:
            (base, busq) = self.path[1:].split('?')
            pedido = cgi.parse_qs(busq, keep_blank_values=1)

            # vemos si es un método nuestro
            accion = "run_%s" % base
            if hasattr(self, accion):
                f = getattr(self, accion)
                contenido = f(pedido)
               
                # contestamos al browser
                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.send_header("Content-length", len(contenido))
                self.end_headers()
                self.wfile.write(contenido)
                return

        SimpleHTTPServer.SimpleHTTPRequestHandler.do_GET(self)
        return
        
    def run_buscar(self, parametros):
        request = parametros['textentry'][0]
        pag = buscarIndice(request)
        return pag
       
if __name__=="__main__":
    if len(sys.argv) != 2 or not sys.argv[1].isdigit():
        print "Usar: server.py <puerto>"
        sys.exit()
    port = int(sys.argv[1])
    s=SocketServer.TCPServer(('',port),ManejaPedidos)
    s.serve_forever()
