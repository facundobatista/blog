# -*- coding: UTF-8 -*-

import threading, Queue, urllib
import htmllib, formatter, urlparse, cPickle, sys

class Parser(htmllib.HTMLParser):

    def __init__(self, base):
        htmllib.HTMLParser.__init__(self, formatter.NullFormatter())
        self.enlaces = []
        self.contenido = []
        self.base = base

    def start_a(self, data):
        """Busca enlaces en los anchors."""
        self.agrega_enlaces([x[1].split("#")[0] for x in data if x[0] == "href"])

    def start_frame(self, data):
        """Busca enlaces en los frames."""
        self.agrega_enlaces([x[1] for x in data if x[0] == "src"])

    def agrega_enlaces(self, links):
        """Agrega los enlaces a los parseados."""
        links = [urlparse.urljoin(self.base, x) for x in links]
        self.enlaces.extend(links)

    def handle_data(self, data):
        """Agrega las palabras del contenido para el índice."""
        partes = data.split()
        self.contenido.extend(partes)
        htmllib.HTMLParser.handle_data(self, data)


class Constructor(threading.Thread):
    """Hilo que arma el índice con las palabras que recibe."""
    def __init__(self, cola, nomarch):
        self.cola = cola
        self.data = {}
        self.archout = open(nomarch, "w")
        threading.Thread.__init__(self)

    def run(self):
        """Loop principal del hilo."""
        while True:
            info = self.cola.get()
            if info is "quit":
                print "Saliendo del constructor"
                self.dumpInfo()
                return
            self.armaIndice(*info)

    def armaIndice(self, titulo, url, palabras):
        """Agregamos al índce cada paquete de palabras recibidas."""
        # precontamos las palabras
        dic = {}
        for pal in palabras:
            dic[pal] = dic.get(pal, 0) + 1

        # agregamos al indice
        for (pal, cant) in dic.items():
            enlaces = self.data.get(pal, {})
            enlaces[url] = (cant, titulo)
            self.data[pal] = enlaces
        return

    def dumpInfo(self):
        """Bajamos a disco el índice."""
        # reordenamos la estructura
        dic = {}
        for (pal, enlacD) in self.data.items():
            enlacL = [(cant, titulo, url) for (url, (cant, titulo)) in enlacD.items()]
            dic[pal] = sorted(enlacL, reverse=True)

        # bajamos a disco
        cPickle.dump(dic, self.archout)
        self.archout.close()
        return


class Analizador(threading.Thread):
    """Hilo que recibe una URL, la trae, la parsea y devuelve la info."""

    def __init__(self, colaRepartIn, colaRepartOut, colaConstructor):
        self.qRepartIn = colaRepartIn
        self.qRepartOut = colaRepartOut
        self.qConstr = colaConstructor
        threading.Thread.__init__(self)

    def run(self):
        while True:
            info = self.qRepartIn.get()
            if info is "quit":
                print "Saliendo del analizador"
                return
            print "Analizando la url %r" % info
            (titulo, enlaces, contenido) = self.analizar(info)
            self.qConstr.put((titulo, info, contenido))
            self.qRepartOut.put(enlaces)

    def analizar(self, url):
        """Trae la URL y la parsea."""
        try:
            f = urllib.urlopen(url)
        except IOError:
            return ([], [], [])
        headers = f.info()
        content_type = headers['content-type']
        if content_type != "text/html":
            return ([], [], [])
        c = f.read()
        p = Parser(url)
        p.feed(c)
        p.close()
        titulo = p.title or url
        return (titulo, p.enlaces, p.contenido)



class Repartidor:
    """Administrador de las URLs a parsear."""
    
    def __init__(self, cant, qConstr, origURL):
        self.cant = cant
        self.qConstr = qConstr
        self.enlaces = [origURL]
        self.url_parseadas = set((origURL,))
        if origURL.endswith(".html") or origURL.endswith(".html"):
             origURL = "/".join(origURL.split("/")[:-1])
        self.base = origURL

        self.disponibles = [True] * cant
        self.qsEnviar = [Queue.Queue() for x in range(cant)]
        self.qsRecibir = [Queue.Queue() for x in range(cant)]
        for i in range(cant):
            analiz = Analizador(self.qsEnviar[i], self.qsRecibir[i], qConstr)
            analiz.start()
        
    def go(self):
        while len(self.enlaces) > 0 or sum(self.disponibles) < self.cant:
            # si hay algun hilo libre, le damos trabajo
            if sum(self.disponibles) > 0:
                self.repartir()

            # revisamos los hilos ocupados
            for i in range(self.cant):
                if self.disponibles[i]:
                    continue
                try:
                    parseados = self.qsRecibir[i].get(timeout=1)
                except Queue.Empty:
                    continue
                # recibimos nuevos links
                parseados = [x for x in parseados if self.validar(x)]
                self.enlaces.extend(parseados)
                self.disponibles[i] = True

        # terminamos, cerremos los hilos
        for cola in self.qsEnviar:
            cola.put("quit")

    def repartir(self):
        """Damos las URLs que tenemos a los hilos libres."""
        for i in range(self.cant):
            if self.disponibles[i]:
                # le pasamos al hilo disponible una URL si la tenemos
                if len(self.enlaces) == 0:
                    return
                newlink = self.enlaces.pop()
                self.qsEnviar[i].put(newlink)
                self.disponibles[i] = False
        return

    def validar(self, url):
        """Vemos si agregamos la URL a la lista para parsear."""
        if url in self.url_parseadas:
            return False
        if not url.startswith(self.base):
            return False
        self.url_parseadas.add(url)
        return True
        
# armamos las colas, al Constructor y al Repartidor
if len(sys.argv) != 2:
    print "Usar crawler.py <link base>\n"
    sys.exit()
linkbase = sys.argv[1]

qConstr = Queue.Queue()
constr = Constructor(qConstr, "indice.dat")
constr.start()

repart = Repartidor(5, qConstr, linkbase)
repart.go()
qConstr.put("quit")
print "Terminamos todo!"
