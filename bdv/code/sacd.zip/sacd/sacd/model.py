from sqlobject import *
from turbogears.database import PackageHub

hub = PackageHub("sacd")
__connection__ = hub

class Disco(SQLObject):
    nombre = StringCol(unique=True)
    autor = StringCol()
    ubicacion = StringCol()
    genero = StringCol()
    canciones = MultipleJoin("Cancion")

class Cancion(SQLObject):
    pos = IntCol()
    nombre = StringCol()
    disco = ForeignKey("Disco")
    autor = StringCol()
    duracion = StringCol()
    letra = StringCol()
