# -*- coding: UTF-8 -*-

import turbogears, cherrypy
from turbogears import controllers

from model import Disco, Cancion

class Root(controllers.Root):
    @turbogears.expose(html="sacd.templates.inicial")
    def index(self, order=1):
        discos = []
        for d in Disco.select():
            if len(d.canciones) > 0:
                accionborrar = ""
            else:
                accionborrar = "Borrar"
            discos.append((d.id, d.nombre, d.autor, d.ubicacion, d.genero, accionborrar))
        order = int(order)
        discos.sort(key=lambda x: x[order])
        return dict(discos=discos)
        
    @turbogears.expose(html="sacd.templates.nuevodisco")
    def nuevoDisco(self):
        return {}

    @turbogears.expose()
    def act_creardisco(self, nombre, autor, ubicacion, genero, submit):
        disco = Disco(nombre=nombre, autor=autor, ubicacion=ubicacion, genero=genero)
        turbogears.flash("Nuevo disco creado!")
        raise cherrypy.HTTPRedirect(turbogears.url("/"))

    @turbogears.expose(html="sacd.templates.editardisco")
    def editarDisco(self, discoid, **data):
        d = Disco.get(discoid)
        if not data:
            nombre = d.nombre
            autor = d.autor
            ubicacion = d.ubicacion
            genero = d.genero
        else:
            nombre = data["nombre"]
            autor = data["autor"]
            ubicacion = data["ubicacion"]
            genero = data["genero"]
        return dict(discoid=discoid, nombre=nombre, autor=autor, ubicacion=ubicacion, genero=genero)

    @turbogears.expose()
    def act_editardisco(self, discoid, nombre, autor, ubicacion, genero, submit):
        d = Disco.get(discoid)
        if d.nombre != nombre and nombre in [x.nombre for x in Disco.select()]:
            turbogears.flash("Ese nombre de disco ya esta usado!")
            raise cherrypy.HTTPRedirect(turbogears.url("/editarDisco", discoid=discoid, nombre=nombre, autor=autor, ubicacion=ubicacion, genero=genero))

        d.set(nombre=nombre, autor=autor, ubicacion=ubicacion, genero=genero)
        turbogears.flash("Se modificó con exito el disco '%s'" % nombre)
        raise cherrypy.HTTPRedirect(turbogears.url("/"))

    @turbogears.expose(html="sacd.templates.borrardisco")
    def borrarDisco(self, discoid):
        d = Disco.get(discoid)
        return dict(discoid=discoid, nombre=d.nombre, autor=d.autor, ubicacion=d.ubicacion, genero=d.genero)

    @turbogears.expose()
    def act_borrardisco(self, discoid, submit):
        d = Disco.get(discoid)
        nombre = d.nombre
        d.destroySelf()
        turbogears.flash("Se borró el disco '%s'" % nombre)
        raise cherrypy.HTTPRedirect(turbogears.url("/"))
    
    @turbogears.expose(html="sacd.templates.listacanciones")
    def listaCanciones(self, discoid, order=1):
        d = Disco.get(discoid)
        canciones = []
        for c in d.canciones:
            if c.letra == "":
                accionletra = "CrearLetra"
            else:
                accionletra = "VerLetra"
            canciones.append((c.id, c.pos, c.nombre, c.autor, c.duracion, accionletra))
        order = int(order)
        canciones.sort(key=lambda x: x[order])
        return dict(canciones=canciones, nomdisco=d.nombre, discoid=discoid)
        
    @turbogears.expose(html="sacd.templates.agregcanciones")
    def agregarCanciones(self, discoid, pos="", nombre="", autor="", duracion=""):
        d = Disco.get(discoid)
        return dict(discoid=discoid, nomdisco=d.nombre, pos=pos, nombre=nombre, autor=autor, duracion=duracion)

    @turbogears.expose()
    def act_agregcanciones(self, discoid, pos, nombre, autor, duracion, submit):
        # nos fijamos si ya esta usada esa posición
        try:
            pos = int(pos)
        except:
            turbogears.flash("La posición debe ser un número!")
            raise cherrypy.HTTPRedirect(turbogears.url("/agregarCanciones", discoid=discoid, pos=pos, nombre=nombre, autor=autor, duracion=duracion))

        d = Disco.get(discoid)
        if pos in [x.pos for x in d.canciones]:
            turbogears.flash("Esa posición ya está usada para este disco!")
            raise cherrypy.HTTPRedirect(turbogears.url("/agregarCanciones", discoid=discoid, pos=pos, nombre=nombre, autor=autor, duracion=duracion))

        cancion = Cancion(pos=pos, nombre=nombre, disco=d, autor=autor, duracion=duracion, letra="")
        turbogears.flash("Nueva canción creada!")
        raise cherrypy.HTTPRedirect(turbogears.url("/listaCanciones", discoid=discoid))

    @turbogears.expose(html="sacd.templates.editarcancion")
    def editarCancion(self, cancionid, **data):
        c = Cancion.get(cancionid)
        if not data:
            pos = c.pos
            nombre = c.nombre
            autor = c.autor
            duracion = c.duracion
        else:
            pos = data["pos"]
            nombre = data["nombre"]
            autor = data["autor"]
            duracion = data["duracion"]
        return dict(discoid=c.disco.id, cancionid=c.id, pos=pos, nombre=nombre, autor=autor, duracion=duracion)

    @turbogears.expose()
    def act_editarcancion(self, cancionid, pos, nombre, autor, duracion, submit):
        try:
            pos = int(pos)
        except:
            turbogears.flash("La posición debe ser un número!")
            raise cherrypy.HTTPRedirect(turbogears.url("/editarCancion", cancionid=cancionid, pos=pos, nombre=nombre, autor=autor, duracion=duracion))

        c = Cancion.get(cancionid)
        if c.pos != pos and pos in [x.pos for x in c.disco.canciones]:
            turbogears.flash("Esa posición ya está usada para este disco!")
            raise cherrypy.HTTPRedirect(turbogears.url("/editarCancion", cancionid=cancionid, pos=pos, nombre=nombre, autor=autor, duracion=duracion))

        c.set(pos=pos, nombre=nombre, autor=autor, duracion=duracion)
        turbogears.flash("Se modificó con exito la canción '%s'" % nombre)
        raise cherrypy.HTTPRedirect(turbogears.url("/listaCanciones", discoid=c.disco.id))

    @turbogears.expose(html="sacd.templates.borrarcancion")
    def borrarCancion(self, cancionid):
        c = Cancion.get(cancionid)
        return dict(discoid=c.disco.id, cancionid=c.id, pos=c.pos, nombre=c.nombre, autor=c.autor, duracion=c.duracion)

    @turbogears.expose()
    def act_borrarcancion(self, cancionid, submit):
        c = Cancion.get(cancionid)
        nombre = c.nombre
        discoid = c.disco.id
        c.destroySelf()
        turbogears.flash("Se borró la canción '%s'" % nombre)
        raise cherrypy.HTTPRedirect(turbogears.url("/listaCanciones", discoid=discoid))

    @turbogears.expose(html="sacd.templates.verletra")
    def verLetra(self, cancionid):
        c = Cancion.get(cancionid)
        return dict(cancionid=cancionid, nombre=c.nombre, letra=c.letra)

    @turbogears.expose()
    def act_grabarletra(self, cancionid, letra, submit):
        print submit
        c = Cancion.get(cancionid)
        if submit == "Grabar":
            c.letra = letra
            turbogears.flash("Se editó correctamente la letra de '%s'!" % c.nombre)
        else:
            turbogears.flash("La letra de '%s' NO se modificó!" % c.nombre)
        raise cherrypy.HTTPRedirect(turbogears.url("/listaCanciones", discoid=c.disco.id))
     
